package com.mmt.qa.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mmt.qa.util.TestUtil;

public class BaseMMT {

	public static WebDriver driver;
	public static WebDriverWait wait;
	public static Properties prop;

	public BaseMMT() {

		try {
			prop = new Properties();

			FileInputStream ip = new FileInputStream(System.getProperty("user.dir") + "/config.properties");

			prop.load(ip);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("file not found");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void initialization() {

		String browserName = prop.getProperty("browser");

		if (browserName.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/driver/chromedriver.exe");//

			ChromeOptions options = new ChromeOptions();
			// Create a instance of ChromeOptions class to handle push notification of the
			// site

			options.addArguments("--disable-notifications");

			// options.addArguments("--incognito");
			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			// Adding Chrome switch to disable notification

			// Passing ChromeOptions instance to ChromeDriver Constructor
			driver = new ChromeDriver(options);
			wait = new WebDriverWait(driver, 100);

		} else if (browserName.equals("FF")) {
			System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/driver/geckodriver");
			FirefoxProfile profile = new FirefoxProfile();
			profile.setPreference("dom.webnotifications.enabled", false);
			driver = new FirefoxDriver();
		}

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_TIME, TimeUnit.SECONDS);

		driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		// driver.get("https://www.makemytrip.com/");
		driver.get(prop.getProperty("url"));

	}

	public static void takeScreenshot(String testMethodName) throws IOException {
		// take screenshot and store it as a file format
		// conveting the driver as TakeScreenshot interface(typecasting)
		File file = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		// copy the screenshot as a file on a desired location using method copyfile
		// FileUtils.copyFile(file, new
		// File("FailCase_"+this.getClass().getName()+"_"+".jpg"));
		FileUtils.copyFile(file,
				new File(System.getProperty("user.dir") + "/Screenshots/" + testMethodName + "_" + ".png"));
	}

}
