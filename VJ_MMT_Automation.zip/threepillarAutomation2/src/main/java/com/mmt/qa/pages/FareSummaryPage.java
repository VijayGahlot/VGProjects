package com.mmt.qa.pages;

//import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.mmt.qa.base.BaseMMT;
//import com.sun.media.jfxmedia.logging.Logger;

public class FareSummaryPage extends BaseMMT

{
	@FindBy(xpath = "//span[@class='coupon-code ng-binding' and contains(text(), 'MMTPAY')]")
	WebElement radioCoupon;

	// @FindBy(xpath="//iframe[contains(@name,'5586290a')]")
	WebElement iframe;

	@FindBy(xpath = "//div[@class='close']")
	WebElement chromeiframe;

	@FindBy(xpath = "//span[contains(@ng-click, 'noInsureClick()')]")
	WebElement checkNoInsur;

	@FindBy(xpath = "//input[contains(@placeholder,'xyz@xyz.com')]")
	WebElement validateEmail;

	@FindBy(xpath = "//a[@id='continueToReview']")
	WebElement continueButton;

	// Initializing FareSummary Page objects
	public FareSummaryPage() {
		PageFactory.initElements(driver, this);

	}

	public String FareSummaryPageTitle() throws InterruptedException {

		Thread.sleep(2000);
		return driver.getTitle();

	}

	public void closeChromeAlert() {

		driver.switchTo().frame("notification-frame-~5586290a");
		driver.findElement(By.xpath("//span[@class='wewidgeticon we_close icon-large']")).click();

	}


	public void checkNoinsure() {
		checkNoInsur.click();

	}

	public FlightsTravellerPage clickOnContinue() {
		continueButton.click();
		return new FlightsTravellerPage();
	}

}
