package com.mmt.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.mmt.qa.base.BaseMMT;

public class FlightsTravellerPage extends BaseMMT {
	@FindBy(xpath = "//input[@placeholder='First Name']")
	WebElement firstName;

	@FindBy(xpath = "//input[@placeholder='Last Name']")
	WebElement lastName;

	@FindBy(xpath = "//p[@class='clearfix append_bottom30']//a[contains(@class,'first pull-left')]")
	WebElement selectGender;
	@FindBy(xpath = "//a[contains(@class,'dblblack_bloker')]")
	WebElement continuePayment;

	// Initializing CheckOut Page objects
	public FlightsTravellerPage() {
		PageFactory.initElements(driver, this);

	}

	public String FlightsTravellerPageTitle() {

		return driver.getTitle();

	}

	public void fillPersonalDetails(String fname, String lname) {
		firstName.sendKeys(fname);
		lastName.sendKeys(lname);
		selectGender.click();
	}

	public PaymentPage continueToPayment() {
		continuePayment.click();
		return new PaymentPage();
	}

}
