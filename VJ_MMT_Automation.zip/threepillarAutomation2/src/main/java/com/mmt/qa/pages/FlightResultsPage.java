package com.mmt.qa.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.mmt.qa.base.BaseMMT;

public class FlightResultsPage extends BaseMMT {

	@FindBy(xpath = "//strong[contains(text(), 'No. of Stops')]")
	WebElement flightPageLabel;

	@FindBy(xpath = "//a[contains(@class,'select_button pull-right')]")
	
	public List<WebElement> bookButton;

	public FlightResultsPage() {
		PageFactory.initElements(driver, this);
	}

	public FareSummaryPage clickOnBookButton(List<WebElement> elem) throws InterruptedException {

		for (int i = 0; i < elem.size(); i++) {
			elem.get(i).click();

		}

		return new FareSummaryPage();

	}

	public String FlightResultsPageTitle() throws InterruptedException {

		return driver.getTitle();

	}

	public boolean verifyFlightPageLabel(String hellotext) {
		return flightPageLabel.getText().equalsIgnoreCase(hellotext);
	}
}
