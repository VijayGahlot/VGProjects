package com.mmt.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.mmt.qa.base.BaseMMT;

public class LoginPage extends BaseMMT {

	// PageFactory -OR
	@FindBy(xpath="//i[contains(@class,'we_close')]")
	WebElement hotelPopUp;

	@FindBy(id = "ch_login_icon")
	WebElement loginIcon;

	@FindBy(id = "ch_login_email")
	WebElement username;

	@FindBy(id = "ch_login_password")
	WebElement password;

	@FindBy(id = "ch_login_btn")
	WebElement loginBtn;
	
	@FindBy(xpath="//div[contains(@class, 'ch__userInteraction')]//ul//li//span[contains(text(), 'Hey Vijay')]")
	WebElement userNameLabel;

	public LoginPage() {
		PageFactory.initElements(driver, this);
	
	}

	public String getPageTitle() throws InterruptedException {
		Thread.sleep(0500);
		return driver.getTitle();
		
	}
	
	public void closeHotelPopUp()
	{
		driver.switchTo().frame("notification-frame-22a34493b");
		hotelPopUp.click();
		
	}

//Alt shift J on method
	/**
	 * @param un
	 * @param pwd
	 * @return
	 * @throws InterruptedException 
	 */
	public HomePage login(String un, String pwd) throws InterruptedException {
		loginIcon.click();
		username.sendKeys(un);
		password.sendKeys(pwd);
		loginBtn.click();
		Thread.sleep(3000);
		return new HomePage();
		

		// HomePage object as HomePage will be reached after completing logging in
	}
	public boolean verifyLoggedInUser(String loggedinuser)
	{
		return userNameLabel.getText().equalsIgnoreCase(loggedinuser);
	}

}
