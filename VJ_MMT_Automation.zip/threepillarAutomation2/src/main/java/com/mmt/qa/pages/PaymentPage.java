package com.mmt.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.mmt.qa.base.BaseMMT;

public class PaymentPage extends BaseMMT {

	@FindBy(xpath = "//p[contains(text(), 'SUMMARY')]")
	WebElement bookSummary;

// Initializing Booking Page objects
	public PaymentPage() {
		PageFactory.initElements(driver, this);

	}

	public String BookingPageTitle() throws InterruptedException {
		Thread.sleep(2000);
		return driver.getTitle();

	}

	public boolean verifybookSummaryLabel(String BookSummary) {
		return bookSummary.getText().equalsIgnoreCase(BookSummary);
	}
}
