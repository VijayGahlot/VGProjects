package com.mmt.qa.tests;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.mmt.qa.base.BaseMMT;
import com.mmt.qa.pages.FlightResultsPage;

import com.mmt.qa.pages.HomePage;
import com.mmt.qa.pages.LoginPage;
import com.mmt.qa.util.TestUtil;

import iTestListenerForScreenshot.ListenerTest;

@Listeners(ListenerTest.class)
public class HomePageTest extends BaseMMT {

	LoginPage loginPage;
	HomePage homePage;
	FlightResultsPage flightResultsPage;
	HomePage wait;
	TestUtil testUtil;

	public HomePageTest() {
		super();// Super keyword to use the Base Class constructor
	}

	@BeforeClass
	public void setUp() throws IOException, InterruptedException {
		initialization();
		loginPage = new LoginPage();
		/* loginPage.closeHotelPopUp(); */
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));

		flightResultsPage = new FlightResultsPage();
		testUtil = new TestUtil();

	}

	@Test(priority = 1, description = "verify Home Page title after logging in")
	public void HomePageTitleTest() {

		String homePageTitle = homePage.HomePageTitle();

		Assert.assertEquals(homePageTitle, "MakeMyTrip - #1 Travel Website 50% OFF on Hotels, Flights & Holiday");

	}

	@Test(priority = 2, description = "verify user name label title after logging in")
	public void verifyuserNameLabelTest() {

		Assert.assertTrue(homePage.verifyLoggedInUser("Hey Vijay"));
		// assertTrue(homePage.verifyLoggedInUser("Hey Vijay"));
	}

	//

	@Test(priority = 3, description = "verify clicking on 'From' Location dropdown")
	public void clickOnFromOriginTest() throws InterruptedException {
		homePage.clickOnFromOrigin();
	}

	@Test(priority = 4, description = "verify selecting city 'from' in Location dropdown")
	public void GetDropDownValuesfromLocation() throws InterruptedException {

		homePage.GetDropDownValuesFrom(homePage.list, prop.getProperty("FromCity"));

	}

	@Test(priority = 5, description = "verify clicking on 'To' Location dropdown")
	public void clickOnToDestinationTest() throws InterruptedException {
		homePage.clickOnToDestination();
	}

	@Test(priority = 6, description = "verify selecting city 'To' in Location dropdown")
	public void GetDropDownValuesToDestination() throws InterruptedException {

		homePage.GetDropDownValuesFrom(homePage.listTo, prop.getProperty("ToCity"));
	}

	@Test(priority = 7, description = "verify calender opens on clicking the date field")
	public void clickOnDatePickerTest() {
		homePage.clickOnDatePicker();
	}

	@Test(priority = 8, description = "verify choosing the date of departure")
	public void testSelectFromDate() throws InterruptedException {

		String date = "10-OCTOBER-2019";
		String splitter[] = date.split("-");
		String month_year = splitter[1];
		String day = splitter[0];
		System.out.println(month_year);
		System.out.println(day);

		homePage.selectDate(homePage.monthyear, (prop.getProperty("monthyear")), homePage.Selectday,
				(prop.getProperty("Selectday")));

	}

	@Test(priority = 9)
	public void clickOnSearchButtonTest() throws InterruptedException {
		homePage.clickOnSearch();
	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}
}
