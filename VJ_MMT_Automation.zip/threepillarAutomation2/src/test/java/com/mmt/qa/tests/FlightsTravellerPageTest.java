package com.mmt.qa.tests;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mmt.qa.base.BaseMMT;
import com.mmt.qa.pages.PaymentPage;
import com.mmt.qa.pages.FareSummaryPage;
import com.mmt.qa.pages.FlightResultsPage;
import com.mmt.qa.pages.FlightsTravellerPage;
import com.mmt.qa.pages.HomePage;
import com.mmt.qa.pages.LoginPage;
import com.mmt.qa.util.TestUtil;

public class FlightsTravellerPageTest extends BaseMMT {

	LoginPage loginPage;
	HomePage homePage;
	TestUtil testutil;
	FlightsTravellerPage wait;
	FlightResultsPage flightResultsPage;
	FareSummaryPage fareSummaryPage;
	FlightsTravellerPage flightsTravellerPage;
	PaymentPage bookingPage;

	public FlightsTravellerPageTest() {
		super();// Super keyword to use the Base Class constructor
	}

	@BeforeClass
	public void setUp() throws InterruptedException {
		initialization();
		testutil = new TestUtil();
		bookingPage = new PaymentPage();
		flightsTravellerPage = new FlightsTravellerPage();
		fareSummaryPage = new FareSummaryPage();
		flightResultsPage = new FlightResultsPage();
		loginPage = new LoginPage();

		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));

		flightResultsPage = homePage.SearchFlight(homePage.list, homePage.listTo, prop.getProperty("FromCity"),
				prop.getProperty("ToCity"), homePage.monthyear, (prop.getProperty("monthyear")), homePage.Selectday,
				(prop.getProperty("Selectday")));

		fareSummaryPage = flightResultsPage.clickOnBookButton(flightResultsPage.bookButton);
		fareSummaryPage.closeChromeAlert();
		flightsTravellerPage = fareSummaryPage.clickOnContinue();

	}

	@Test(priority = 1, description = "Fare Summary Page Tital ")
	public void FareSummaryPageTitleTest() {

		String flightsTravellerPageTitle = flightsTravellerPage.FlightsTravellerPageTitle();

		Assert.assertEquals(flightsTravellerPageTitle, "Flights Traveller");

	}

	@Test(priority = 2, description = "Fill personal details test")
	public void fillPersonalDetailsTest() {

		flightsTravellerPage.fillPersonalDetails(prop.getProperty("fname"), prop.getProperty("lname"));

	}

	@Test(priority = 3, description = "clicking on continue to payment page")
	public void continueToPaymentTest() {
		bookingPage = flightsTravellerPage.continueToPayment();
	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}

}
