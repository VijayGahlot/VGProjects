package com.mmt.qa.tests;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mmt.qa.base.BaseMMT;
import com.mmt.qa.pages.FareSummaryPage;
import com.mmt.qa.pages.FlightResultsPage;

import com.mmt.qa.pages.HomePage;
import com.mmt.qa.pages.LoginPage;
import com.mmt.qa.util.TestUtil;

public class FlightResultsPageTest extends BaseMMT {

	LoginPage loginPage;
	HomePage homePage;
	TestUtil testutil;
	FlightResultsPage flightResultsPage;
	FareSummaryPage fareSummaryPage;

	public FlightResultsPageTest() {
		super();// Super keyword to use the Base Class constructor
	}

	@BeforeClass
	public void setUp() throws InterruptedException {
		initialization();
		testutil = new TestUtil();
		// flightResultsPage = new FlightResultsPage();
		loginPage = new LoginPage();
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));

		flightResultsPage = homePage.SearchFlight(homePage.list, homePage.listTo, prop.getProperty("FromCity"),
				prop.getProperty("ToCity"), homePage.monthyear, (prop.getProperty("monthyear")), homePage.Selectday,
				(prop.getProperty("Selectday")));

	}

	@Test(priority = 1, description = "verify Flight Results  Page title after logging in")
	public void FlightResultsPageTitleTest() throws InterruptedException {

		String flightResultsPageTitle = flightResultsPage.FlightResultsPageTitle();

		Assert.assertEquals(flightResultsPageTitle, "Flight Search");

	}

	@Test(priority = 2, description = "verify user name label title after logging in")
	public void verifyverifytagLineLabelTest() {
		Assert.assertTrue(flightResultsPage.verifyFlightPageLabel("No. of Stops"));
	}

	@Test(priority = 3, description = " Click on book button")
	public void clickonBookButtonTest() throws InterruptedException {
		fareSummaryPage = flightResultsPage.clickOnBookButton(flightResultsPage.bookButton);

	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}

}
