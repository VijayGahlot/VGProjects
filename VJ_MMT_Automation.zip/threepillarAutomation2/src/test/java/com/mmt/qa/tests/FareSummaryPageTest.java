package com.mmt.qa.tests;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mmt.qa.base.BaseMMT;
import com.mmt.qa.pages.FlightsTravellerPage;
import com.mmt.qa.pages.FareSummaryPage;
import com.mmt.qa.pages.FlightResultsPage;
import com.mmt.qa.pages.HomePage;
import com.mmt.qa.pages.LoginPage;
import com.mmt.qa.util.TestUtil;

public class FareSummaryPageTest extends BaseMMT {
	LoginPage loginPage;
	HomePage homePage;
	TestUtil testutil;
	FlightResultsPage flightResultsPage;
	FareSummaryPage fareSummaryPage;
	FlightsTravellerPage flightsTravellerPage;

	public FareSummaryPageTest() {
		super();// Super keyword to use the Base Class constructor
	}

	@BeforeClass
	public void setUp() throws InterruptedException {
		initialization();
		testutil = new TestUtil();
		fareSummaryPage = new FareSummaryPage();
		flightResultsPage = new FlightResultsPage();
		loginPage = new LoginPage();

		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));

		flightResultsPage = homePage.SearchFlight(homePage.list, homePage.listTo, prop.getProperty("FromCity"),
				prop.getProperty("ToCity"), homePage.monthyear, (prop.getProperty("monthyear")), homePage.Selectday,
				(prop.getProperty("Selectday")));

		fareSummaryPage = flightResultsPage.clickOnBookButton(flightResultsPage.bookButton);

	}

	@Test(priority = 1, description = "verify Flight Review Page title after logging in")
	public void FareSummaryPageTitleTest() throws InterruptedException {

		String fareSummaryPageTitle = fareSummaryPage.FareSummaryPageTitle();

		Assert.assertEquals(fareSummaryPageTitle, "Flights Review");

	}

	@Test(priority = 2, description = "Close pop-up")
	public void closeChromeAlertTest() {

		fareSummaryPage.closeChromeAlert();
	}

	@Test(priority = 3, description = "select no insurance box")
	public void checkNoinsureTest() {
		fareSummaryPage.checkNoinsure();

	}

	@Test(priority = 4, description = "click continue button")
	public void clickOnContinueTest() {
		flightsTravellerPage = fareSummaryPage.clickOnContinue();
	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}
}
