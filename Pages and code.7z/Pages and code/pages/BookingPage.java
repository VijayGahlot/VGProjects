package com.mmt.qa.pages;

import com.mmt.qa.base.BaseMMT;


public class BookingPage extends BaseMMT
{

}
